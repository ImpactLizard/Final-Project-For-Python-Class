"""
Author: Wesley Reynolds
Name: FINAL SDEV140 GUI PROJECT
Last Edited: November 30, 2021

**************IMPORTANT**************

anything that you see '*DEBUGGING*' by 
means that the line is strictly for 
debugging. Commenting out lines which 
say '*DEBUGGING*' will not inhibit the 
functionality of the program.
"""
# --------------------IMPORT MODULES--------------------
from tkinter import *
import tkinter.messagebox
import random
# --------------CREATE THE INTRODUCTION WINDOW--------------
splashScreen = Tk()
splashScreen.title('Color Guessing Game')
splashScreen.geometry("500x420")
splashScreen.resizable(width = False, height = False)
splashScreen.protocol("WM_DELETE_WINDOW", lambda: HideSplashScreen())

onStartup = True

bg = PhotoImage(file="SplashScreenBackground.png")

canvas = Canvas(splashScreen, width = 500, height = 420)
canvas.pack(fill = 'both', expand = True)

canvas.create_image(0, 0, image = bg, anchor = 'nw')

headerString = 'Welcome to the Color Guessing Game!'

message = "Hello there user. I'm looking foward to playing with you.\n\
Just in case you don't know how to play, I'll explain the\n\
rules. I'll generate a specific sequence of colors that\n\
you will try to guess in 10 turns. After each guess, I\n\
will provide hints to you, one that lets you know if you\n\
got a color in the right place, and one that lets you know\n\
if you got a right color in the wrong place. At the startup\n\
you will see 6 colors on the top of the screen, and four\n\
white squares directly below. To assign colors, click on\n\
one of the six colors, and then click on one of the white\n\
squares to assign the selected color to it. Once you are \n\
done assigning your colors, click the pink 'Enter' button.\n\
Below the four white buttons, you will see four black\n\
squares; these hide the correct colors that I will be\n\
comparing your guess to. For a more in depth explanation,\n\
read the provided user manual."

# Create Text Header
canvas.create_text(250, 20, font = ("Comic Sans", 20), text = headerString, fill = '#BBBBBB')

# Create body text
canvas.create_text(250, 210, font = ("Helvetica", 14), text = message, fill = "#BBBBBB")

loadGame = Button(splashScreen, font = ("Helvetica", 14), text = "Let's Play!", bg = '#AAAAAA', activebackground = '#EEEEEE', fg = "#333333", command = lambda: PlayGame())

loadGameWindow = canvas.create_window(390, 415, anchor = 'sw', window = loadGame)

def HideSplashScreen():
    """This function destorys the splash screen on startup
    and withdraws it after the game window has been loaded"""
    if onStartup:
        splashScreen.destroy()
    else:
        splashScreen.withdraw()

# --------------------CREATE MAIN WINDOW--------------------
def PlayGame():
    """This funtion creates the main game window"""
    global onStartup
    onStartup = False

    splashScreen.withdraw()
    gameWindow = Toplevel()
    gameWindow.title('Color Guessing Game')
    gameWindow.geometry("405x200")
    gameWindow.resizable(width = False, height = False)
    gameWindow.configure(bg = "#45D5AF")
    gameWindow.protocol("WM_DELETE_WINDOW", lambda: onExit())

    # --------------------INITIALIZE GLOBAL VARIABLES--------------------
    # List to hold all possible colors
    global colorChoices
    colorChoices = ['red', 'orange', 'yellow', 'green', 'blue', 'purple']

    # Create a list that holds the colors of buttons when they are clicked
    global activeBackgroundColors
    activeBackgroundColors = ['#FF7F7F', '#FFCC7F', '#FFF898', '#40AD38', '#4763FF', '#C673FF']

    # List to hold the color palette buttons
    global colorButtons
    colorButtons = ['Blank', 'Blank', 'Blank', 'Blank', 'Blank', 'Blank']

    # list to hold the guess buttons
    global guessButtons
    guessButtons = ['Blank', 'Blank', 'Blank', 'Blank']
    # List to hold the color attributes of the color guess buttons
    global colorGuess
    colorGuess = ['Blank', 'Blank', 'Blank', 'Blank']

    # List the hold the correct buttons
    global correctButtons
    correctButtons = ['Blank', 'Blank', 'Blank', 'Blank']
    # List tot hold the correct color sequence
    global correctColors
    correctColors = ['Blank', 'Blank', 'Blank', 'Blank']

    # List to hold all buttons types
    global allColorButtonTypes
    allColorButtonTypes = [guessButtons, colorButtons, correctButtons]

    global currentColor
    currentColor = "white" # Global variable for selected color

    # --------------------DEFINE FUNCTIONS--------------------
    def main():
        """This function calls all the nessecary functions to
        create the buttons and labels on the screen"""
        global turns
        turns = 1

        # Generate four random colors to populate the correct colors list
        for index in range(len(correctColors)):
            correctColors[index] = random.choice(colorChoices)

        # Create all buttons
        for index in range(len(allColorButtonTypes)):
            CreateColorButtons(allColorButtonTypes[index], index)

        # Create the color enter button
        CreateEnterButton()

        # Create Help Button
        CreateHelpButton()

        # Creat Turn Label
        CreateTurnLabel()

        # Create a label for debugging
        # CreateLabel() # *DEBUGGING*

    def SetColorState(button):
        """This function sets the global selected color to whichever color 
        button the user pressed"""
        global currentColor

        # Set the current color to the boackground color of the selected button
        currentColor = button.cget("bg")
        
        # Update the label to the current selected color
        # UpdateLabel() # *DEBUGGING*

    def ColorChange(button):
        """This changes the clicked geuss button to the current selected color"""
        button.configure(bg = currentColor)

    # *DEBUGGING*
    def CreateLabel():
        """This function creates a label for displaying the current selected color"""
        global statusBar
        statusBar = Label(gameWindow, text = currentColor)
        statusBar.grid(row = 10, column = 20, columnspan = 3)

    # *DUBUGGING*
    def UpdateLabel():
        # This updates a label to the surrent selected color
        statusBar.configure(text = currentColor)

    def CreateColorButtons(buttonList ,i):
        """This function creates all buttons except the help and enter button"""
        for index in range(len(buttonList)):
            if buttonList == colorButtons:
                # Create the color palette buttons
                buttonList[index] = Button(gameWindow, bg = colorChoices[index], padx = 19, pady = 10, borderwidth = 5, activebackground = activeBackgroundColors[index])
                buttonList[index].configure(command = lambda input = buttonList[index]: SetColorState(input))
                buttonList[index].grid(row = 2, column = 2 * (index + 1), sticky = W)
            elif buttonList == guessButtons:
                # Create the Selectable buttons
                buttonList[index] = Button(gameWindow, bg = "white", padx = 19, pady = 10, borderwidth = 5)
                buttonList[index].configure(command = lambda input = buttonList[index]: ColorChange(input))
                buttonList[index].grid(row = 6, column = 2 * (index + 1), sticky = W)
            else:
                # Create the correct color buttons
                buttonList[index] = Button(gameWindow, bg = 'black', padx = 19, pady = 10, borderwidth = 5)
                
                buttonList[index].grid(row = 30, column = 2 * (index + 1), sticky = W)
                buttonList[index]["state"] = DISABLED

    def CreateEnterButton():
        """This function creates the enter button"""
        global enterButton
        enterButton = Button(gameWindow, bg = 'pink', font = ("Helvecta", 18), text = "Enter", padx = 2, pady = 2, borderwidth = 5, command = CheckColors)
        enterButton.grid(row = 30, column = 12, sticky = W)

    def CreateHelpButton():
        """This function creates the help button"""
        helpButton = Button(gameWindow, bg = 'pink', font = ("Helvecta", 10), text = "Help", padx = 1, pady = 0, borderwidth = 3, command = Help)
        helpButton.grid(row = 32, column = 2)

    def CreateTurnLabel():
        """This function creates the label to display the turn count"""
        global turnLabel
        turnLabel = Label(gameWindow, bg = "#45D5AF", text = "Turn: 1", font = ("Helvecta", 10))
        turnLabel.grid(row = 2, column = 14)

    def Help():
        """This function reshows the splash screen"""
        splashScreen.deiconify()

        loadGame.configure(command = HideSplashScreen)

    def CheckColors():
        """This function is whatt the computer uses to analye the user guess and output hints accordingly"""

        # Create a list of the colors of the guess buttons    
        for index in range(len(guessButtons)):
            colorGuess[index] = guessButtons[index].cget('bg')

        # Assign list to allow guess wrapping
        guessPosition = [0, 1, 2, 3, 0, 1, 2]

        isCorrect = [False, False, False, False]


        rightColors = 0
        rightPlaces = 0
        # Evaluate for right color in right position
        for index in range(4):
            if colorGuess[index] == correctColors[index]:
                rightPlaces += 1
                isCorrect[index] = True
                if rightPlaces == 4:
                    Win()
                    return

        # print(str(isCorrect) + '\n') # *DEBUGGING*
        
        # Evaluate for right color in wrong position
        for index in range(4):
            # print('current index:', index, '-', isCorrect, '-', colorGuess[index], index, '-', correctColors[guessPosition[index + 1]], guessPosition[index + 1]) # *DEBUGGING*
            if colorGuess[index] == correctColors[guessPosition[index + 1]] and not isCorrect[guessPosition[index + 1]]:
                rightColors += 1
                isCorrect[guessPosition[index + 1]] = True
                # print('if statement 1 was reached') # *DEBUGGING*
                continue
            # print('current index:', index, '-', isCorrect, '-', colorGuess[index], index, '-', correctColors[guessPosition[index + 2]], guessPosition[index + 2]) # *DEBUGGING*
            if colorGuess[index] == correctColors[guessPosition[index + 2]] and not isCorrect[guessPosition[index + 2]]:
                rightColors += 1
                isCorrect[guessPosition[index + 2]] = True
                # print('if statement 2 was reached') # *DEBUGGING*
                continue
            # print('current index:', index, '-', isCorrect, '-', colorGuess[index], index, '-', correctColors[guessPosition[index + 3]], guessPosition[index + 3]) # *DEBUGGING*
            if colorGuess[index] == correctColors[guessPosition[index + 3]] and not isCorrect[guessPosition[index + 3]]:
                rightColors += 1
                isCorrect[guessPosition[index + 3]] = True
                # print('if statement 3 was reached') # *DEBUGGING*
            # print() # *DEBUGGING*
        # print(isCorrect) # *DEBUGGING*

        global turns
        if turns == 10:
            Lose()
            return

        AddNewButtonLayer(rightPlaces, rightColors)

        turns += 1
        turnLabel.configure(text = "Turn: " + str(turns))

    # This is called when the user correctly guess the computer's color sequence
    def Win():
        """This function is called when the user correctly guess the computer's color sequence"""

        # Set the black squares to the correct color sequence so that the user can see they have won
        for index in range(len(correctColors)):
            correctButtons[index].configure(bg = correctColors[index])

        DisableGameButtons()

        # Ouput a window telling the user that he/she has won
        if turns == 1:
            PlayAgain("Awesome! You guessed my pattern in the first try!", "Congragulations!", "You Won!")
        else:
            PlayAgain("Hooray! You guessed my pattern in " + str(turns) + " turns.", "Congragulations!", "You Won!")

    # This is called when the user falis to gues the computer's color sequence in the specified number of turns
    def Lose():

        # Set the black squares to the correct color sequence so that the user can see they have won
        for index in range(len(correctColors)):
            correctButtons[index].configure(bg = correctColors[index])

        DisableGameButtons()

        # Ouput a window telling the user that he/she has lost
        PlayAgain("Uh oh! It looks like you ran out of turns.", "Better Luck Next Time!", "You Lost!")

    def AddNewButtonLayer(num1, num2):
        """This solidifies the user's last guess, and generates a new line of guess buttons."""
        global turns

        for button in guessButtons:
            button['state'] = DISABLED

        for index in range(len(guessButtons) - 4, len(guessButtons)):
            guessButtons[index] = Button(gameWindow, bg = "white", padx = 19, pady = 10, borderwidth = 5)
            guessButtons[index].configure(command = lambda input = guessButtons[index]: ColorChange(input))
            guessButtons[index].grid(row = 6 + 2 * turns, column = 2 * (index + 1), sticky = W)

        guessLabel = Label(gameWindow, text = "Right place: " + str(num1) + "\nWrong place: " + str(num2), bg = "#45D5AF")
        guessLabel.grid(row = 4 + 2 * turns, column = 12)

        height = 200 + 50 * turns
        height = str(height)
        diminsions = "405x" + height

        gameWindow.geometry(diminsions)


    def DisableGameButtons():
        """Disable Buttons on maing game"""
        for index in range(len(allColorButtonTypes)):
            for i in range(len(allColorButtonTypes[index])):
                if allColorButtonTypes[index] == correctButtons:
                    pass
                else:
                    for i in range(len(allColorButtonTypes[index])):
                        allColorButtonTypes[index][i]["state"] = DISABLED

        enterButton["state"] = DISABLED

    def PlayAgain(bodyText, titleText, headerText):
        """This creates a window telling the user if he/she has won or lost, and asks 
        them if they want to play again"""
        global again
        again = Tk()
        again.title(titleText)
        if turns == 1:
            again.geometry("450x100")
        else:
            again.geometry("400x100")
        again.resizable(width = False, height = False)
        again.configure(bg = "#ADCDF0")
        again.grab_set()
        again.protocol("WM_DELETE_WINDOW", lambda: onExit())

        header = Label(again, bg = "#ADCDF0", font = ("Comic Sans", 20), text = headerText)
        header.pack()

        text = Label(again, bg = "#ADCDF0", font = ("Comic Sans", 14), text = bodyText)
        text.pack()

        againButton = Button(again, bg = "#85CFFF", activebackground = "#ADE1FF", text = "Play Again?", command = lambda: Restart(again))
        againButton.pack()

    def onExit():
        """This function ends the entire program"""
        exit()

    def Restart(window):
        """This reloads the main game window, and destroys the play again window"""
        turnLabel.configure(text = "Turn: 1")

        gameWindow.destroy()

        PlayGame()

        window.destroy()

    if __name__ == '__main__':
        main()

mainloop()